# 👑 MX2 CROWN SYSTEM - Complete Integration Guide

## Executive Summary

The MX2 CROWN System is a decentralized AI ecosystem that combines:
- **Modular AI Personalities** (Crowns) with switchable behaviors
- **ASX Token Economy** on Base Network (Coinbase L2)
- **Non-custodial Wallet Management**
- **Marketplace for AI Tapes** (custom model configurations)
- **N-gram Training with SCX Compression**
- **Social Rewards & Token Gates**
- **Fiat-to-Crypto Bridge** via Stripe

---

## 📋 Table of Contents

1. [ASX Token Integration](#asx-token-integration)
2. [API Configuration](#api-configuration)
3. [Crown System Architecture](#crown-system-architecture)
4. [AI Model Tapes (API Routes)](#ai-model-tapes)
5. [N-gram Training with SCX](#n-gram-training)
6. [Token Economy & Gates](#token-economy)
7. [Marketplace](#marketplace)
8. [Non-Custodial Wallet](#wallet-system)
9. [Social Rewards](#social-rewards)
10. [Security & Best Practices](#security)

---

## 🪙 ASX Token Integration

### Contract Details

| Parameter | Value |
|-----------|-------|
| **Contract Address** | `0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe` |
| **Network** | Base Mainnet (Coinbase L2) |
| **Chain ID** | `0x2105` (8453 decimal) |
| **Symbol** | ASX |
| **Decimals** | 18 |
| **Explorer** | https://basescan.org/address/0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe |
| **RPC URL** | https://mainnet.base.org |

### Token Flow

```
User → Stripe Payment (USD)
    ↓
Backend Webhook Verification
    ↓
Smart Contract mint() on Base
    ↓
Tokens → User's MetaMask Wallet
    ↓
Balance Visible on BaseScan
```

### Token Utility

- **AI Model Access** (Premium crowns)
- **Marketplace Transactions** (Buy/Sell custom tapes)
- **Training Credits** (Submit RLHF feedback)
- **Storage Expansion** (Increase n-gram capacity)
- **Social Rewards** (Share/refer bonuses)
- **API Rate Limits** (Higher tiers = more requests)

---

## 🔑 API Configuration

### Required API Keys (Admin Settings)

```json
{
  "stripe": {
    "public_key": "pk_live_xxxxx",
    "secret_key": "sk_live_xxxxx",
    "webhook_secret": "whsec_xxxxx"
  },
  "coinbase": {
    "api_key": "xxxxx",
    "api_secret": "xxxxx",
    "webhook_secret": "xxxxx"
  },
  "metamask": {
    "infura_project_id": "xxxxx",
    "wallet_connect_id": "xxxxx"
  },
  "etherscan": {
    "api_key": "xxxxx"
  },
  "basescan": {
    "api_key": "xxxxx"
  },
  "blockchain": {
    "admin_private_key": "ENV_VARIABLE_ONLY",
    "rpc_url": "https://mainnet.base.org"
  }
}
```

### BaseScan API Endpoints

```javascript
// Get ASX Token Balance
GET https://api.basescan.org/api
  ?module=account
  &action=tokenbalance
  &contractaddress=0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe
  &address={USER_WALLET}
  &tag=latest
  &apikey={YOUR_API_KEY}

// Get Transaction History
GET https://api.basescan.org/api
  ?module=account
  &action=tokentx
  &contractaddress=0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe
  &address={USER_WALLET}
  &startblock=0
  &endblock=99999999
  &sort=desc
  &apikey={YOUR_API_KEY}
```

---

## 🏗️ Crown System Architecture

### What is a Crown?

A **Crown** is a modular AI personality with:
- Unique configuration (`crown.json`)
- Custom lexicon (`lexicon.json`)
- API routing tape (`api-tape.json`)
- Theme/UI styling
- Behavioral traits

### Crown Structure

```
/crowns/
  ├── MX2LM/           # Local Ollama model
  ├── MX2ORCA/         # Advanced reasoning
  ├── MX2CLAUDE/       # Anthropic Claude
  ├── MX2GPT/          # OpenAI GPT-4
  ├── MX2GEMINI/       # Google Gemini
  ├── MX2HYBRID/       # Multi-model fusion
  └── CUSTOM/          # User-created crowns
```

### Crown.json Schema

```json
{
  "id": "mx2_claude",
  "name": "Claude Crown",
  "version": "1.0.0",
  "description": "Anthropic Claude API integration",
  "theme": {
    "color": "#B97C47",
    "icon": "👑"
  },
  "api_tape": "claude_tape.json",
  "lexicon": "lexicon.json",
  "token_cost": 50,
  "tier": "premium",
  "capabilities": [
    "reasoning",
    "coding",
    "analysis"
  ]
}
```

---

## 🤖 AI Model Tapes (API Routes)

### Tape Configuration Format

```json
{
  "name": "OpenAI GPT-4",
  "endpoint": "https://api.openai.com/v1/chat/completions",
  "method": "POST",
  "headers": {
    "Authorization": "Bearer {API_KEY}",
    "Content-Type": "application/json"
  },
  "body_template": {
    "model": "gpt-4-turbo-preview",
    "messages": [
      {"role": "system", "content": "{SYSTEM_PROMPT}"},
      {"role": "user", "content": "{USER_INPUT}"}
    ],
    "max_tokens": 4096,
    "temperature": 0.7
  },
  "response_path": "choices[0].message.content",
  "cost_per_1k_tokens": 0.01
}
```

### Complete Tape Collection

#### 1. OpenAI Tapes

**GPT-4 Turbo**
```json
{
  "name": "OpenAI GPT-4 Turbo",
  "id": "openai_gpt4_turbo",
  "endpoint": "https://api.openai.com/v1/chat/completions",
  "method": "POST",
  "headers": {
    "Authorization": "Bearer {API_KEY}",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "gpt-4-turbo-preview",
    "messages": "{MESSAGES}",
    "max_tokens": 4096,
    "temperature": 0.7
  },
  "response_path": "choices[0].message.content",
  "requires_api_key": true,
  "token_cost": 100
}
```

**GPT-3.5 Turbo**
```json
{
  "name": "OpenAI GPT-3.5 Turbo",
  "id": "openai_gpt35_turbo",
  "endpoint": "https://api.openai.com/v1/chat/completions",
  "body": {
    "model": "gpt-3.5-turbo",
    "messages": "{MESSAGES}",
    "max_tokens": 4096
  },
  "token_cost": 20
}
```

#### 2. Anthropic Claude Tapes

**Claude Opus**
```json
{
  "name": "Anthropic Claude Opus",
  "id": "anthropic_claude_opus",
  "endpoint": "https://api.anthropic.com/v1/messages",
  "method": "POST",
  "headers": {
    "x-api-key": "{API_KEY}",
    "anthropic-version": "2023-06-01",
    "content-type": "application/json"
  },
  "body": {
    "model": "claude-3-opus-20240229",
    "max_tokens": 4096,
    "messages": "{MESSAGES}"
  },
  "response_path": "content[0].text",
  "requires_api_key": true,
  "token_cost": 150
}
```

**Claude Sonnet**
```json
{
  "name": "Anthropic Claude Sonnet",
  "id": "anthropic_claude_sonnet",
  "endpoint": "https://api.anthropic.com/v1/messages",
  "body": {
    "model": "claude-3-sonnet-20240229",
    "max_tokens": 4096,
    "messages": "{MESSAGES}"
  },
  "token_cost": 75
}
```

**Claude Haiku**
```json
{
  "name": "Anthropic Claude Haiku",
  "id": "anthropic_claude_haiku",
  "body": {
    "model": "claude-3-haiku-20240307",
    "max_tokens": 4096,
    "messages": "{MESSAGES}"
  },
  "token_cost": 25
}
```

#### 3. Google Gemini Tapes

**Gemini Pro**
```json
{
  "name": "Google Gemini Pro",
  "id": "google_gemini_pro",
  "endpoint": "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent",
  "method": "POST",
  "headers": {
    "Content-Type": "application/json"
  },
  "query_params": {
    "key": "{API_KEY}"
  },
  "body": {
    "contents": [
      {
        "parts": [
          {"text": "{USER_INPUT}"}
        ]
      }
    ],
    "generationConfig": {
      "temperature": 0.7,
      "maxOutputTokens": 2048
    }
  },
  "response_path": "candidates[0].content.parts[0].text",
  "requires_api_key": true,
  "token_cost": 50
}
```

**Gemini Ultra**
```json
{
  "name": "Google Gemini Ultra",
  "id": "google_gemini_ultra",
  "endpoint": "https://generativelanguage.googleapis.com/v1/models/gemini-ultra:generateContent",
  "body": {
    "contents": "{CONTENTS}",
    "generationConfig": {
      "temperature": 0.9,
      "maxOutputTokens": 4096
    }
  },
  "token_cost": 200
}
```

#### 4. Meta Llama Tapes

**Llama 3 70B**
```json
{
  "name": "Meta Llama 3 70B",
  "id": "meta_llama3_70b",
  "endpoint": "https://api.together.xyz/v1/chat/completions",
  "headers": {
    "Authorization": "Bearer {API_KEY}",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "meta-llama/Llama-3-70b-chat-hf",
    "messages": "{MESSAGES}",
    "max_tokens": 4096
  },
  "response_path": "choices[0].message.content",
  "token_cost": 40
}
```

#### 5. Cohere Tapes

**Command**
```json
{
  "name": "Cohere Command",
  "id": "cohere_command",
  "endpoint": "https://api.cohere.ai/v1/chat",
  "headers": {
    "Authorization": "Bearer {API_KEY}",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "command",
    "message": "{USER_INPUT}",
    "chat_history": "{HISTORY}"
  },
  "response_path": "text",
  "token_cost": 30
}
```

#### 6. Mistral AI Tapes

**Mistral Large**
```json
{
  "name": "Mistral Large",
  "id": "mistral_large",
  "endpoint": "https://api.mistral.ai/v1/chat/completions",
  "headers": {
    "Authorization": "Bearer {API_KEY}",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "mistral-large-latest",
    "messages": "{MESSAGES}"
  },
  "response_path": "choices[0].message.content",
  "token_cost": 60
}
```

#### 7. Perplexity Tapes

**Perplexity Online**
```json
{
  "name": "Perplexity Online",
  "id": "perplexity_online",
  "endpoint": "https://api.perplexity.ai/chat/completions",
  "headers": {
    "Authorization": "Bearer {API_KEY}",
    "Content-Type": "application/json"
  },
  "body": {
    "model": "pplx-70b-online",
    "messages": "{MESSAGES}"
  },
  "response_path": "choices[0].message.content",
  "token_cost": 80
}
```

#### 8. Local Ollama Tapes

**Llama 2**
```json
{
  "name": "Ollama Llama 2",
  "id": "ollama_llama2",
  "endpoint": "http://localhost:11434/api/generate",
  "method": "POST",
  "body": {
    "model": "llama2",
    "prompt": "{USER_INPUT}",
    "stream": false
  },
  "response_path": "response",
  "requires_api_key": false,
  "token_cost": 0,
  "offline": true
}
```

**Mixtral**
```json
{
  "name": "Ollama Mixtral",
  "id": "ollama_mixtral",
  "endpoint": "http://localhost:11434/api/generate",
  "body": {
    "model": "mixtral",
    "prompt": "{USER_INPUT}",
    "stream": false
  },
  "token_cost": 0,
  "offline": true
}
```

#### 9. Hybrid Tapes (Multi-Model)

**Consensus Voting**
```json
{
  "name": "Hybrid Consensus",
  "id": "hybrid_consensus",
  "type": "hybrid",
  "strategy": "voting",
  "models": [
    "openai_gpt4_turbo",
    "anthropic_claude_opus",
    "google_gemini_pro"
  ],
  "voting_method": "majority",
  "token_cost": 300,
  "description": "Queries 3 top models and returns majority consensus"
}
```

**Best-of-N Sampling**
```json
{
  "name": "Hybrid Best-of-N",
  "id": "hybrid_best_of_n",
  "type": "hybrid",
  "strategy": "best_of_n",
  "models": [
    "openai_gpt35_turbo",
    "anthropic_claude_haiku"
  ],
  "n": 5,
  "scoring_function": "perplexity",
  "token_cost": 150
}
```

**Cascade Routing**
```json
{
  "name": "Hybrid Cascade",
  "id": "hybrid_cascade",
  "type": "hybrid",
  "strategy": "cascade",
  "cascade": [
    {
      "model": "ollama_llama2",
      "confidence_threshold": 0.8
    },
    {
      "model": "openai_gpt35_turbo",
      "confidence_threshold": 0.9
    },
    {
      "model": "anthropic_claude_opus",
      "confidence_threshold": 1.0
    }
  ],
  "token_cost": "dynamic",
  "description": "Tries fast model first, escalates if confidence low"
}
```

**Mixture of Experts**
```json
{
  "name": "Hybrid MoE",
  "id": "hybrid_moe",
  "type": "hybrid",
  "strategy": "mixture_of_experts",
  "router_model": "ollama_llama2",
  "experts": {
    "coding": "openai_gpt4_turbo",
    "creative": "anthropic_claude_opus",
    "factual": "perplexity_online",
    "reasoning": "google_gemini_ultra"
  },
  "token_cost": "dynamic"
}
```

---

## 🧠 N-gram Training with SCX Compression

### Enhanced N-gram System (3x Expansion)

#### Standard N-gram Files
```
/ASX-RAM/v1/ngrams/
  ├── unigrams.json        # 50,000 tokens
  ├── bigrams.json         # 500,000 pairs
  ├── trigrams.json        # 1,500,000 triples
  ├── quadgrams.json       # 3,000,000 quads (NEW)
  ├── pentagrams.json      # 4,500,000 pents (NEW)
  └── meta-intent-map.json # Intent routing
```

#### SCX Compression Format

**SCX (Symbolic Cipher eXchange)** reduces n-gram storage by 75% using:
1. **Dictionary Encoding** - Common words → 2-byte IDs
2. **Run-Length Encoding** - Repeated sequences compressed
3. **Huffman Coding** - Frequency-based bit allocation
4. **Delta Encoding** - Store confidence score differences

**Example:**
```javascript
// Uncompressed Trigram (120 bytes)
{
  "the quick brown": {
    "confidence": 0.847,
    "count": 1523,
    "last_seen": "2024-01-15T12:00:00Z",
    "contexts": ["writing", "stories", "general"]
  }
}

// SCX Compressed (32 bytes)
{
  "t": "0x4F2A1B",
  "c": 847,
  "n": 1523,
  "ts": 1705320000,
  "ctx": [0, 1, 2]
}
```

#### SCX Implementation

```javascript
// scx-compressor.js
class SCXCompressor {
  constructor() {
    this.dictionary = new Map();
    this.reverseDict = new Map();
    this.nextId = 0;
  }

  compress(ngrams) {
    const compressed = {
      version: "SCX-1.0",
      dict: [],
      data: []
    };

    // Build dictionary
    for (const phrase in ngrams) {
      const words = phrase.split(' ');
      words.forEach(word => {
        if (!this.dictionary.has(word)) {
          const id = this.nextId++;
          this.dictionary.set(word, id);
          this.reverseDict.set(id, word);
          compressed.dict.push(word);
        }
      });
    }

    // Encode n-grams
    for (const [phrase, data] of Object.entries(ngrams)) {
      const ids = phrase.split(' ').map(w => this.dictionary.get(w));
      compressed.data.push({
        i: ids,
        c: Math.round(data.confidence * 1000),
        n: data.count,
        ts: new Date(data.last_seen).getTime() / 1000,
        ctx: data.contexts.map(c => this.getContextId(c))
      });
    }

    return compressed;
  }

  decompress(compressed) {
    const ngrams = {};
    
    for (const item of compressed.data) {
      const phrase = item.i.map(id => compressed.dict[id]).join(' ');
      ngrams[phrase] = {
        confidence: item.c / 1000,
        count: item.n,
        last_seen: new Date(item.ts * 1000).toISOString(),
        contexts: item.ctx.map(id => this.getContextName(id))
      };
    }

    return ngrams;
  }
}
```

#### Training Pipeline

```javascript
// ngram-trainer.js
class NgramTrainer {
  async train(inputText, score) {
    // Extract n-grams
    const extracted = {
      unigrams: this.extractUnigrams(inputText),
      bigrams: this.extractBigrams(inputText),
      trigrams: this.extractTrigrams(inputText),
      quadgrams: this.extractQuadgrams(inputText),
      pentagrams: this.extractPentagrams(inputText)
    };

    // Update confidence scores
    for (const [type, grams] of Object.entries(extracted)) {
      await this.updateScores(type, grams, score);
    }

    // Compress and save
    const compressed = await this.compressAll(extracted);
    await this.saveToStorage(compressed);

    // Sync to network
    await this.syncToSwarm(compressed);
  }

  extractQuadgrams(text) {
    const words = text.split(/\s+/);
    const quads = [];
    for (let i = 0; i < words.length - 3; i++) {
      quads.push(words.slice(i, i + 4).join(' '));
    }
    return quads;
  }

  extractPentagrams(text) {
    const words = text.split(/\s+/);
    const pents = [];
    for (let i = 0; i < words.length - 4; i++) {
      pents.push(words.slice(i, i + 5).join(' '));
    }
    return pents;
  }
}
```

#### Meta-Intent Mapping

```json
{
  "meta_intents": {
    "query": {
      "patterns": ["what is", "how to", "why does"],
      "confidence_boost": 0.1
    },
    "command": {
      "patterns": ["create", "build", "make"],
      "confidence_boost": 0.15
    },
    "creative": {
      "patterns": ["write a", "imagine", "story about"],
      "confidence_boost": 0.2
    },
    "analytical": {
      "patterns": ["analyze", "compare", "evaluate"],
      "confidence_boost": 0.12
    },
    "conversational": {
      "patterns": ["hey", "hello", "thanks"],
      "confidence_boost": 0.05
    }
  }
}
```

---

## 💰 Token Economy & Gates

### Token Distribution

```javascript
const TOKEN_ECONOMY = {
  daily_free_tokens: 100,
  signup_bonus: 500,
  referral_bonus: 200,
  share_bonus: 50,
  
  costs: {
    basic_query: 1,
    premium_crown: 50,
    hybrid_model: 100,
    custom_tape: 10,
    marketplace_listing: 25,
    storage_1gb: 500,
    api_call_burst: 200
  },
  
  rewards: {
    good_feedback: 5,
    training_submission: 10,
    tape_purchase: 0.7, // 70% to creator
    successful_referral: 200
  }
}
```

### Token Gates

```javascript
// token-gate.js
class TokenGate {
  async checkAccess(userId, feature) {
    const balance = await this.getBalance(userId);
    const cost = TOKEN_ECONOMY.costs[feature];
    
    if (balance < cost) {
      return {
        allowed: false,
        reason: "insufficient_tokens",
        required: cost,
        current: balance,
        deficit: cost - balance
      };
    }
    
    await this.deductTokens(userId, cost);
    return { allowed: true };
  }
  
  async grantDailyTokens(userId) {
    const lastClaim = await this.getLastClaim(userId);
    const now = new Date();
    
    if (now - lastClaim > 86400000) { // 24 hours
      await this.addTokens(userId, TOKEN_ECONOMY.daily_free_tokens);
      await this.updateLastClaim(userId, now);
      return true;
    }
    
    return false;
  }
}
```

### Stripe Integration

```javascript
// stripe-handler.js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

app.post('/api/purchase-tokens', async (req, res) => {
  const { amount, userId } = req.body;
  
  // Create payment intent
  const paymentIntent = await stripe.paymentIntents.create({
    amount: amount * 100, // cents
    currency: 'usd',
    metadata: { userId, tokenAmount: amount * 10 } // $1 = 10 tokens
  });
  
  res.json({ clientSecret: paymentIntent.client_secret });
});

app.post('/api/stripe-webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const event = stripe.webhooks.constructEvent(
    req.body,
    sig,
    process.env.STRIPE_WEBHOOK_SECRET
  );
  
  if (event.type === 'payment_intent.succeeded') {
    const { userId, tokenAmount } = event.data.object.metadata;
    
    // Mint ASX tokens on Base
    await mintASXTokens(userId, tokenAmount);
    
    // Add tokens to user's balance
    await addTokensToBalance(userId, tokenAmount);
  }
  
  res.json({ received: true });
});
```

---

## 🏪 Marketplace

### Marketplace Features

1. **Submit Custom Tapes** - Users create and sell AI configurations
2. **Set Pricing** - Flexible ASX token pricing
3. **Revenue Split** - 70% creator, 30% platform
4. **Rating System** - 5-star reviews with comments
5. **Featured Tapes** - Promoted listings for extra cost
6. **Version Control** - Update tapes without breaking compatibility

### Tape Submission

```json
{
  "tape_id": "user_tape_001",
  "name": "Marketing Copy Expert",
  "description": "Specialized in writing compelling ad copy",
  "creator": "0xUserWallet...",
  "price": 250,
  "category": "writing",
  "tags": ["marketing", "copywriting", "ads"],
  "version": "1.0.0",
  "config": {
    "model": "openai_gpt4_turbo",
    "system_prompt": "You are an expert marketing copywriter...",
    "temperature": 0.8,
    "max_tokens": 2048
  },
  "stats": {
    "downloads": 0,
    "rating": 0,
    "reviews": []
  }
}
```

### Marketplace API

```javascript
// marketplace.js
class Marketplace {
  async submitTape(userId, tapeConfig) {
    // Charge listing fee
    await this.deductTokens(userId, 25);
    
    // Generate tape ID
    const tapeId = `tape_${Date.now()}_${userId.slice(0, 8)}`;
    
    // Store in database
    await db.tapes.insert({
      id: tapeId,
      creator: userId,
      config: tapeConfig,
      created_at: new Date(),
      status: 'active'
    });
    
    return tapeId;
  }
  
  async purchaseTape(buyerId, tapeId) {
    const tape = await db.tapes.findOne({ id: tapeId });
    
    // Check balance
    const balance = await this.getBalance(buyerId);
    if (balance < tape.price) {
      throw new Error('Insufficient tokens');
    }
    
    // Transfer tokens
    await this.deductTokens(buyerId, tape.price);
    await this.addTokens(tape.creator, tape.price * 0.7); // 70% to creator
    await this.addTokens('platform', tape.price * 0.3); // 30% to platform
    
    // Grant access
    await db.purchases.insert({
      buyer: buyerId,
      tape: tapeId,
      price: tape.price,
      purchased_at: new Date()
    });
    
    // Update stats
    await db.tapes.update(
      { id: tapeId },
      { $inc: { 'stats.downloads': 1 } }
    );
    
    return tape.config;
  }
  
  async rateTape(userId, tapeId, rating, review) {
    // Check if user owns tape
    const purchase = await db.purchases.findOne({
      buyer: userId,
      tape: tapeId
    });
    
    if (!purchase) {
      throw new Error('Must own tape to rate');
    }
    
    await db.tapes.update(
      { id: tapeId },
      {
        $push: {
          'stats.reviews': {
            user: userId,
            rating,
            review,
            date: new Date()
          }
        }
      }
    );
    
    // Recalculate average rating
    const tape = await db.tapes.findOne({ id: tapeId });
    const avgRating = tape.stats.reviews.reduce((sum, r) => sum + r.rating, 0) / tape.stats.reviews.length;
    
    await db.tapes.update(
      { id: tapeId },
      { $set: { 'stats.rating': avgRating } }
    );
  }
}
```

---

## 👛 Non-Custodial Wallet System

### Wallet Features

1. **Client-Side Key Generation** - Private keys never leave device
2. **WebCrypto Encryption** - AES-256-GCM for local storage
3. **MetaMask Integration** - Connect existing wallets
4. **Multi-Chain Support** - Base, Ethereum, Polygon
5. **Transaction Signing** - Sign locally, broadcast remotely
6. **Backup & Recovery** - 12-word mnemonic phrases

### Wallet Implementation

```javascript
// wallet.js
class NonCustodialWallet {
  async createWallet(password) {
    // Generate mnemonic
    const mnemonic = bip39.generateMnemonic();
    
    // Derive keypair
    const seed = await bip39.mnemonicToSeed(mnemonic);
    const wallet = ethers.Wallet.fromMnemonic(mnemonic);
    
    // Encrypt private key
    const encrypted = await this.encrypt(wallet.privateKey, password);
    
    // Store encrypted key
    await localStorage.setItem('wallet_encrypted', encrypted);
    await localStorage.setItem('wallet_address', wallet.address);
    
    return {
      address: wallet.address,
      mnemonic, // Show once, user must save
      encrypted
    };
  }
  
  async encrypt(data, password) {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    
    // Derive key from password
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      'PBKDF2',
      false,
      ['deriveKey']
    );
    
    const key = await crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: encoder.encode('asx-wallet-salt'),
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt']
    );
    
    // Generate IV
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    // Encrypt
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      dataBuffer
    );
    
    // Combine IV + encrypted data
    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encrypted), iv.length);
    
    return btoa(String.fromCharCode(...combined));
  }
  
  async decrypt(encryptedData, password) {
    // Reverse of encrypt()
    // ... implementation
  }
  
  async getBalance(address) {
    const provider = new ethers.providers.JsonRpcProvider(
      'https://mainnet.base.org'
    );
    
    const contract = new ethers.Contract(
      '0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe',
      ['function balanceOf(address) view returns (uint256)'],
      provider
    );
    
    const balance = await contract.balanceOf(address);
    return ethers.utils.formatUnits(balance, 18);
  }
  
  async sendTransaction(to, amount, password) {
    // Decrypt wallet
    const encryptedKey = await localStorage.getItem('wallet_encrypted');
    const privateKey = await this.decrypt(encryptedKey, password);
    
    const wallet = new ethers.Wallet(privateKey);
    const provider = new ethers.providers.JsonRpcProvider(
      'https://mainnet.base.org'
    );
    const signer = wallet.connect(provider);
    
    // Send transaction
    const tx = await signer.sendTransaction({
      to,
      value: ethers.utils.parseEther(amount)
    });
    
    return tx.hash;
  }
}
```

### MetaMask Integration

```javascript
// metamask-connector.js
class MetaMaskConnector {
  async connect() {
    if (!window.ethereum) {
      throw new Error('MetaMask not installed');
    }
    
    // Request account access
    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });
    
    // Switch to Base network
    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: '0x2105' }]
      });
    } catch (switchError) {
      // Network not added, add it
      if (switchError.code === 4902) {
        await this.addBaseNetwork();
      }
    }
    
    // Add ASX token
    await this.addASXToken();
    
    return accounts[0];
  }
  
  async addBaseNetwork() {
    await window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [{
        chainId: '0x2105',
        chainName: 'Base Mainnet',
        nativeCurrency: {
          name: 'Ethereum',
          symbol: 'ETH',
          decimals: 18
        },
        rpcUrls: ['https://mainnet.base.org'],
        blockExplorerUrls: ['https://basescan.org']
      }]
    });
  }
  
  async addASXToken() {
    await window.ethereum.request({
      method: 'wallet_watchAsset',
      params: {
        type: 'ERC20',
        options: {
          address: '0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe',
          symbol: 'ASX',
          decimals: 18
        }
      }
    });
  }
}
```

---

## 🌟 Social Rewards

### Reward Actions

```javascript
const SOCIAL_REWARDS = {
  twitter_share: 50,
  facebook_share: 30,
  linkedin_share: 40,
  reddit_post: 60,
  youtube_review: 200,
  blog_article: 300,
  github_star: 25,
  discord_invite: 100,
  referral_signup: 200,
  referral_purchase: 500
};
```

### Share Tracking

```javascript
// social-rewards.js
class SocialRewards {
  async trackShare(userId, platform, url) {
    // Verify share exists
    const verified = await this.verifyShare(platform, url);
    
    if (!verified) {
      throw new Error('Share not found or invalid');
    }
    
    // Check if already claimed
    const existing = await db.shares.findOne({
      user: userId,
      platform,
      url
    });
    
    if (existing) {
      throw new Error('Reward already claimed');
    }
    
    // Award tokens
    const reward = SOCIAL_REWARDS[`${platform}_share`];
    await this.addTokens(userId, reward);
    
    // Record share
    await db.shares.insert({
      user: userId,
      platform,
      url,
      reward,
      claimed_at: new Date()
    });
    
    return reward;
  }
  
  async verifyShare(platform, url) {
    // Check if URL contains user's share link
    // This would use OAuth APIs for each platform
    // Simplified example:
    
    switch (platform) {
      case 'twitter':
        // Use Twitter API to verify tweet exists
        return await this.verifyTwitter(url);
      case 'facebook':
        return await this.verifyFacebook(url);
      // etc.
    }
  }
  
  async generateReferralLink(userId) {
    const code = crypto.randomBytes(8).toString('hex');
    
    await db.referrals.insert({
      user: userId,
      code,
      created_at: new Date(),
      uses: 0
    });
    
    return `https://mx2crown.com/ref/${code}`;
  }
  
  async trackReferral(referralCode, newUserId) {
    const referral = await db.referrals.findOne({ code: referralCode });
    
    if (!referral) {
      return;
    }
    
    // Award referrer
    await this.addTokens(referral.user, SOCIAL_REWARDS.referral_signup);
    
    // Award new user
    await this.addTokens(newUserId, 500); // Signup bonus
    
    // Update referral stats
    await db.referrals.update(
      { code: referralCode },
      { $inc: { uses: 1 } }
    );
  }
}
```

### Social Share UI

```html
<!-- share-buttons.html -->
<div class="social-rewards">
  <h3>Earn ASX Tokens by Sharing!</h3>
  
  <button onclick="shareOnTwitter()">
    <i class="fab fa-twitter"></i>
    Share on Twitter (+50 ASX)
  </button>
  
  <button onclick="shareOnFacebook()">
    <i class="fab fa-facebook"></i>
    Share on Facebook (+30 ASX)
  </button>
  
  <button onclick="shareOnLinkedIn()">
    <i class="fab fa-linkedin"></i>
    Share on LinkedIn (+40 ASX)
  </button>
  
  <div class="referral-section">
    <h4>Your Referral Link:</h4>
    <input type="text" id="referral-link" readonly />
    <button onclick="copyReferralLink()">Copy</button>
    <p>Earn 200 ASX for each signup!</p>
  </div>
</div>
```

---

## 🔒 Security & Best Practices

### Security Checklist

- [x] **Private Keys** - Stored only in environment variables
- [x] **Webhook Verification** - All webhooks verified via signature
- [x] **Rate Limiting** - API calls rate-limited per user
- [x] **Input Sanitization** - All user input sanitized
- [x] **HTTPS Only** - All connections encrypted
- [x] **CORS** - Proper CORS headers configured
- [x] **Token Expiry** - JWT tokens expire after 1 hour
- [x] **2FA Support** - Optional two-factor authentication
- [x] **Audit Logs** - All token transactions logged
- [x] **Smart Contract Audit** - Contract audited before mainnet
- [x] **Non-Custodial** - Users always control their keys

### Best Practices

1. **Never store private keys in database**
2. **Use environment variables for all secrets**
3. **Verify all Stripe webhooks with signatures**
4. **Rate limit API calls (100/hour for free tier)**
5. **Implement circuit breakers for external APIs**
6. **Cache BaseScan results for 30 seconds**
7. **Use WebSockets for real-time balance updates**
8. **Implement exponential backoff for retries**
9. **Monitor gas prices and adjust dynamically**
10. **Regular security audits every quarter**

### Environment Variables

```bash
# .env
STRIPE_PUBLIC_KEY=pk_live_xxxxx
STRIPE_SECRET_KEY=sk_live_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx

COINBASE_API_KEY=xxxxx
COINBASE_API_SECRET=xxxxx

INFURA_PROJECT_ID=xxxxx
WALLET_CONNECT_ID=xxxxx

ETHERSCAN_API_KEY=xxxxx
BASESCAN_API_KEY=xxxxx

ADMIN_PRIVATE_KEY=xxxxx
BASE_RPC_URL=https://mainnet.base.org

OPENAI_API_KEY=sk-xxxxx
ANTHROPIC_API_KEY=sk-ant-xxxxx
GOOGLE_API_KEY=xxxxx

JWT_SECRET=xxxxx
ENCRYPTION_KEY=xxxxx

DATABASE_URL=postgresql://xxxxx
REDIS_URL=redis://xxxxx
```

---

## 🚀 Quick Start Guide

### 1. Install Dependencies

```bash
npm install ethers bip39 stripe @coinbase/wallet-sdk
```

### 2. Configure Environment

Copy `.env.example` to `.env` and fill in your API keys.

### 3. Initialize Wallet

```javascript
const wallet = new NonCustodialWallet();
await wallet.createWallet('your-secure-password');
```

### 4. Add ASX Token to MetaMask

```javascript
const metamask = new MetaMaskConnector();
const address = await metamask.connect();
```

### 5. Start Using Crowns

```javascript
const crown = await ASX.loadCrown('MX2CLAUDE');
const response = await crown.chat('Hello!');
```

---

## 📚 Additional Resources

- **ASX Token Contract**: https://basescan.org/address/0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe
- **Documentation**: https://docs.mx2crown.com
- **Discord**: https://discord.gg/mx2crown
- **GitHub**: https://github.com/mx2crown
- **API Reference**: https://api.mx2crown.com/docs

---

## 📄 License

MIT License - Use freely for commercial or personal projects

---

**Built with ❤️ by the MX2 CROWN Team**

*Decentralized AI for Everyone* 🚀👑
