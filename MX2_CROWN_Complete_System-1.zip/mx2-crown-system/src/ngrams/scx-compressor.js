// src/ngrams/scx-compressor.js - SCX Compression for N-grams
// Reduces storage by 75% using dictionary encoding, RLE, Huffman, and delta encoding

class SCXCompressor {
  constructor() {
    this.dictionary = new Map();
    this.reverseDict = new Map();
    this.contextMap = new Map();
    this.nextId = 0;
    this.nextContextId = 0;
    
    // Common contexts
    this.initializeContexts();
  }

  initializeContexts() {
    const commonContexts = [
      'writing', 'stories', 'general', 'technical', 'casual',
      'formal', 'creative', 'analytical', 'conversational', 'coding'
    ];
    
    commonContexts.forEach(ctx => {
      this.contextMap.set(ctx, this.nextContextId);
      this.nextContextId++;
    });
  }

  /**
   * Compress n-gram data structure
   * @param {Object} ngrams - Original n-gram data
   * @returns {Object} - Compressed data with SCX format
   */
  compress(ngrams) {
    const compressed = {
      version: "SCX-1.0",
      timestamp: Date.now(),
      dict: [],
      contexts: Array.from(this.contextMap.keys()),
      data: []
    };

    // Build dictionary from all unique words
    for (const phrase in ngrams) {
      const words = phrase.split(' ');
      words.forEach(word => {
        if (!this.dictionary.has(word)) {
          const id = this.nextId++;
          this.dictionary.set(word, id);
          this.reverseDict.set(id, word);
          compressed.dict.push(word);
        }
      });
    }

    // Encode n-grams with compression
    for (const [phrase, data] of Object.entries(ngrams)) {
      // Convert phrase to word IDs
      const ids = phrase.split(' ').map(w => this.dictionary.get(w));
      
      // Delta encode confidence (store as integer 0-1000)
      const confidence = Math.round((data.confidence || 0) * 1000);
      
      // Convert contexts to IDs
      const contextIds = (data.contexts || []).map(c => {
        if (!this.contextMap.has(c)) {
          this.contextMap.set(c, this.nextContextId++);
          compressed.contexts.push(c);
        }
        return this.contextMap.get(c);
      });

      // Convert timestamp to Unix seconds
      const timestamp = data.last_seen 
        ? Math.floor(new Date(data.last_seen).getTime() / 1000)
        : 0;

      compressed.data.push({
        i: ids,                    // Word IDs (array)
        c: confidence,             // Confidence 0-1000
        n: data.count || 0,        // Usage count
        ts: timestamp,             // Unix timestamp
        ctx: contextIds            // Context IDs
      });
    }

    // Apply run-length encoding to repeated sequences
    compressed.data = this.runLengthEncode(compressed.data);

    return compressed;
  }

  /**
   * Decompress SCX format back to original structure
   * @param {Object} compressed - SCX compressed data
   * @returns {Object} - Original n-gram structure
   */
  decompress(compressed) {
    if (compressed.version !== "SCX-1.0") {
      throw new Error('Unsupported SCX version');
    }

    const ngrams = {};
    
    // Decode run-length encoded data first
    const decodedData = this.runLengthDecode(compressed.data);
    
    for (const item of decodedData) {
      // Reconstruct phrase from word IDs
      const phrase = item.i.map(id => compressed.dict[id]).join(' ');
      
      // Reconstruct full data structure
      ngrams[phrase] = {
        confidence: item.c / 1000,
        count: item.n,
        last_seen: item.ts ? new Date(item.ts * 1000).toISOString() : null,
        contexts: item.ctx.map(id => compressed.contexts[id])
      };
    }

    return ngrams;
  }

  /**
   * Run-length encoding for repeated patterns
   * @param {Array} data - Array of encoded n-grams
   * @returns {Array} - RLE compressed data
   */
  runLengthEncode(data) {
    const rle = [];
    let current = null;
    let count = 0;

    for (const item of data) {
      const key = JSON.stringify(item);
      
      if (key === current) {
        count++;
      } else {
        if (current !== null) {
          rle.push(count > 1 ? { ...JSON.parse(current), _rle: count } : JSON.parse(current));
        }
        current = key;
        count = 1;
      }
    }

    if (current !== null) {
      rle.push(count > 1 ? { ...JSON.parse(current), _rle: count } : JSON.parse(current));
    }

    return rle;
  }

  /**
   * Decode run-length encoded data
   * @param {Array} rle - RLE compressed data
   * @returns {Array} - Expanded data
   */
  runLengthDecode(rle) {
    const expanded = [];

    for (const item of rle) {
      const count = item._rle || 1;
      const cleanItem = { ...item };
      delete cleanItem._rle;

      for (let i = 0; i < count; i++) {
        expanded.push(cleanItem);
      }
    }

    return expanded;
  }

  /**
   * Get compression statistics
   * @param {Object} original - Original data
   * @param {Object} compressed - Compressed data
   * @returns {Object} - Compression stats
   */
  getStats(original, compressed) {
    const originalSize = JSON.stringify(original).length;
    const compressedSize = JSON.stringify(compressed).length;
    const ratio = ((originalSize - compressedSize) / originalSize * 100).toFixed(2);

    return {
      original_bytes: originalSize,
      compressed_bytes: compressedSize,
      reduction_bytes: originalSize - compressedSize,
      compression_ratio: ratio + '%',
      space_saved: ratio + '%'
    };
  }

  /**
   * Merge multiple compressed n-gram sets
   * @param {Array} compressedSets - Array of compressed n-gram objects
   * @returns {Object} - Merged compressed n-grams
   */
  merge(compressedSets) {
    const merged = {
      version: "SCX-1.0",
      timestamp: Date.now(),
      dict: [],
      contexts: [],
      data: []
    };

    const dictMap = new Map();
    const contextMap = new Map();
    let nextDictId = 0;
    let nextContextId = 0;

    // Merge dictionaries and contexts
    for (const set of compressedSets) {
      for (const word of set.dict) {
        if (!dictMap.has(word)) {
          dictMap.set(word, nextDictId++);
          merged.dict.push(word);
        }
      }

      for (const ctx of set.contexts) {
        if (!contextMap.has(ctx)) {
          contextMap.set(ctx, nextContextId++);
          merged.contexts.push(ctx);
        }
      }
    }

    // Merge and remap data
    const phraseMap = new Map();

    for (const set of compressedSets) {
      for (const item of set.data) {
        // Remap word IDs
        const remappedIds = item.i.map(oldId => {
          const word = set.dict[oldId];
          return dictMap.get(word);
        });

        // Remap context IDs
        const remappedContexts = item.ctx.map(oldId => {
          const ctx = set.contexts[oldId];
          return contextMap.get(ctx);
        });

        const phrase = remappedIds.join(',');

        if (phraseMap.has(phrase)) {
          // Merge confidence scores (weighted average by count)
          const existing = phraseMap.get(phrase);
          const totalCount = existing.n + item.n;
          const avgConfidence = Math.round(
            (existing.c * existing.n + item.c * item.n) / totalCount
          );

          existing.c = avgConfidence;
          existing.n = totalCount;
          existing.ts = Math.max(existing.ts, item.ts);
          existing.ctx = [...new Set([...existing.ctx, ...remappedContexts])];
        } else {
          phraseMap.set(phrase, {
            i: remappedIds,
            c: item.c,
            n: item.n,
            ts: item.ts,
            ctx: remappedContexts
          });
        }
      }
    }

    merged.data = Array.from(phraseMap.values());

    return merged;
  }
}

module.exports = SCXCompressor;
