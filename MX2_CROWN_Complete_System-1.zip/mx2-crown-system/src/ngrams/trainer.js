// src/ngrams/trainer.js - N-gram Training System (3x expansion with SCX)

const SCXCompressor = require('./scx-compressor');
const fs = require('fs').promises;
const path = require('path');

class NgramTrainer {
  constructor(storageDir = './ASX-RAM/v1/ngrams') {
    this.storageDir = storageDir;
    this.compressor = new SCXCompressor();
    
    // In-memory caches
    this.unigrams = new Map();
    this.bigrams = new Map();
    this.trigrams = new Map();
    this.quadgrams = new Map();
    this.pentagrams = new Map();
    
    // Meta-intent mapping
    this.metaIntents = {
      query: { patterns: ['what is', 'how to', 'why does', 'when', 'where'], boost: 0.1 },
      command: { patterns: ['create', 'build', 'make', 'generate'], boost: 0.15 },
      creative: { patterns: ['write a', 'imagine', 'story about'], boost: 0.2 },
      analytical: { patterns: ['analyze', 'compare', 'evaluate'], boost: 0.12 },
      conversational: { patterns: ['hey', 'hello', 'thanks', 'please'], boost: 0.05 }
    };
  }

  /**
   * Initialize trainer and load existing n-grams
   */
  async initialize() {
    await this.ensureDirectories();
    await this.loadAll();
  }

  /**
   * Ensure storage directories exist
   */
  async ensureDirectories() {
    await fs.mkdir(this.storageDir, { recursive: true });
  }

  /**
   * Train on new input text with RLHF score
   * @param {string} inputText - Text to train on
   * @param {number} score - RLHF score (0-1)
   * @param {string} context - Context tag
   */
  async train(inputText, score = 1.0, context = 'general') {
    // Normalize text
    const normalized = this.normalizeText(inputText);
    
    // Detect intent
    const intent = this.detectIntent(normalized);
    const intentBoost = this.metaIntents[intent]?.boost || 0;
    
    // Adjust score based on intent
    const adjustedScore = Math.min(1.0, score + intentBoost);
    
    // Extract all n-grams
    const extracted = {
      unigrams: this.extractUnigrams(normalized),
      bigrams: this.extractBigrams(normalized),
      trigrams: this.extractTrigrams(normalized),
      quadgrams: this.extractQuadgrams(normalized),
      pentagrams: this.extractPentagrams(normalized)
    };

    // Update scores for each type
    for (const [type, grams] of Object.entries(extracted)) {
      await this.updateScores(type, grams, adjustedScore, context);
    }

    // Compress and save
    await this.saveAll();

    return {
      trained: true,
      counts: {
        unigrams: extracted.unigrams.length,
        bigrams: extracted.bigrams.length,
        trigrams: extracted.trigrams.length,
        quadgrams: extracted.quadgrams.length,
        pentagrams: extracted.pentagrams.length
      },
      intent,
      adjusted_score: adjustedScore
    };
  }

  /**
   * Normalize text for training
   * @param {string} text - Raw input text
   * @returns {string} - Normalized text
   */
  normalizeText(text) {
    return text
      .toLowerCase()
      .replace(/[^\w\s'-]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Detect intent from text
   * @param {string} text - Normalized text
   * @returns {string} - Detected intent
   */
  detectIntent(text) {
    for (const [intent, config] of Object.entries(this.metaIntents)) {
      for (const pattern of config.patterns) {
        if (text.includes(pattern)) {
          return intent;
        }
      }
    }
    return 'general';
  }

  /**
   * Extract unigrams (single words)
   * @param {string} text - Normalized text
   * @returns {Array} - Array of unigrams
   */
  extractUnigrams(text) {
    return text.split(/\s+/).filter(w => w.length > 0);
  }

  /**
   * Extract bigrams (word pairs)
   * @param {string} text - Normalized text
   * @returns {Array} - Array of bigrams
   */
  extractBigrams(text) {
    const words = text.split(/\s+/);
    const bigrams = [];
    for (let i = 0; i < words.length - 1; i++) {
      bigrams.push(`${words[i]} ${words[i + 1]}`);
    }
    return bigrams;
  }

  /**
   * Extract trigrams (three-word phrases)
   * @param {string} text - Normalized text
   * @returns {Array} - Array of trigrams
   */
  extractTrigrams(text) {
    const words = text.split(/\s+/);
    const trigrams = [];
    for (let i = 0; i < words.length - 2; i++) {
      trigrams.push(`${words[i]} ${words[i + 1]} ${words[i + 2]}`);
    }
    return trigrams;
  }

  /**
   * Extract quadgrams (four-word sequences)
   * @param {string} text - Normalized text
   * @returns {Array} - Array of quadgrams
   */
  extractQuadgrams(text) {
    const words = text.split(/\s+/);
    const quadgrams = [];
    for (let i = 0; i < words.length - 3; i++) {
      quadgrams.push(`${words[i]} ${words[i + 1]} ${words[i + 2]} ${words[i + 3]}`);
    }
    return quadgrams;
  }

  /**
   * Extract pentagrams (five-word patterns)
   * @param {string} text - Normalized text
   * @returns {Array} - Array of pentagrams
   */
  extractPentagrams(text) {
    const words = text.split(/\s+/);
    const pentagrams = [];
    for (let i = 0; i < words.length - 4; i++) {
      pentagrams.push(`${words[i]} ${words[i + 1]} ${words[i + 2]} ${words[i + 3]} ${words[i + 4]}`);
    }
    return pentagrams;
  }

  /**
   * Update confidence scores for n-grams
   * @param {string} type - N-gram type
   * @param {Array} grams - Array of n-grams
   * @param {number} score - Confidence score
   * @param {string} context - Context tag
   */
  async updateScores(type, grams, score, context) {
    const map = this[type];

    for (const gram of grams) {
      if (map.has(gram)) {
        const existing = map.get(gram);
        
        // Exponential moving average for confidence
        const alpha = 0.3;
        existing.confidence = alpha * score + (1 - alpha) * existing.confidence;
        existing.count += 1;
        existing.last_seen = new Date().toISOString();
        
        if (!existing.contexts.includes(context)) {
          existing.contexts.push(context);
        }
      } else {
        map.set(gram, {
          confidence: score,
          count: 1,
          last_seen: new Date().toISOString(),
          contexts: [context]
        });
      }
    }
  }

  /**
   * Generate text using n-gram predictions
   * @param {string} seed - Starting text
   * @param {number} maxLength - Maximum words to generate
   * @returns {string} - Generated text
   */
  async generate(seed, maxLength = 50) {
    const words = seed.trim().split(/\s+/);
    let generated = [...words];

    for (let i = 0; i < maxLength; i++) {
      const context = generated.slice(-4).join(' ');
      const nextWord = await this.predictNext(context);
      
      if (!nextWord) break;
      
      generated.push(nextWord);
    }

    return generated.join(' ');
  }

  /**
   * Predict next word based on context
   * @param {string} context - Previous words
   * @returns {string} - Predicted next word
   */
  async predictNext(context) {
    // Try pentagram first (most specific)
    let candidates = this.findCandidates(context, this.pentagrams);
    
    // Fall back to quadgram
    if (candidates.length === 0) {
      candidates = this.findCandidates(context, this.quadgrams);
    }
    
    // Fall back to trigram
    if (candidates.length === 0) {
      candidates = this.findCandidates(context, this.trigrams);
    }
    
    // Fall back to bigram
    if (candidates.length === 0) {
      candidates = this.findCandidates(context, this.bigrams);
    }

    if (candidates.length === 0) return null;

    // Weighted random selection based on confidence
    return this.weightedRandomChoice(candidates);
  }

  /**
   * Find candidate next words
   * @param {string} context - Context string
   * @param {Map} map - N-gram map
   * @returns {Array} - Array of {word, confidence} objects
   */
  findCandidates(context, map) {
    const candidates = [];
    
    for (const [gram, data] of map.entries()) {
      if (gram.startsWith(context + ' ')) {
        const nextWord = gram.split(' ').pop();
        candidates.push({
          word: nextWord,
          confidence: data.confidence
        });
      }
    }

    return candidates;
  }

  /**
   * Weighted random choice
   * @param {Array} candidates - Array of {word, confidence}
   * @returns {string} - Selected word
   */
  weightedRandomChoice(candidates) {
    const totalWeight = candidates.reduce((sum, c) => sum + c.confidence, 0);
    let random = Math.random() * totalWeight;

    for (const candidate of candidates) {
      random -= candidate.confidence;
      if (random <= 0) {
        return candidate.word;
      }
    }

    return candidates[0].word;
  }

  /**
   * Save all n-grams with SCX compression
   */
  async saveAll() {
    const types = ['unigrams', 'bigrams', 'trigrams', 'quadgrams', 'pentagrams'];
    
    for (const type of types) {
      const data = Object.fromEntries(this[type]);
      const compressed = this.compressor.compress(data);
      
      const filePath = path.join(this.storageDir, `${type}.scx.json`);
      await fs.writeFile(filePath, JSON.stringify(compressed, null, 2));
      
      // Log compression stats
      const stats = this.compressor.getStats(data, compressed);
      console.log(`${type} compression:`, stats);
    }
  }

  /**
   * Load all n-grams from storage
   */
  async loadAll() {
    const types = ['unigrams', 'bigrams', 'trigrams', 'quadgrams', 'pentagrams'];
    
    for (const type of types) {
      const filePath = path.join(this.storageDir, `${type}.scx.json`);
      
      try {
        const compressed = JSON.parse(await fs.readFile(filePath, 'utf8'));
        const decompressed = this.compressor.decompress(compressed);
        this[type] = new Map(Object.entries(decompressed));
        
        console.log(`Loaded ${this[type].size} ${type}`);
      } catch (err) {
        console.log(`No existing ${type} found, starting fresh`);
        this[type] = new Map();
      }
    }
  }

  /**
   * Get statistics about n-gram storage
   * @returns {Object} - Statistics
   */
  getStats() {
    return {
      unigrams: this.unigrams.size,
      bigrams: this.bigrams.size,
      trigrams: this.trigrams.size,
      quadgrams: this.quadgrams.size,
      pentagrams: this.pentagrams.size,
      total: this.unigrams.size + this.bigrams.size + this.trigrams.size + 
             this.quadgrams.size + this.pentagrams.size
    };
  }

  /**
   * Merge n-grams from another trainer or file
   * @param {string|Object} source - File path or trainer object
   */
  async merge(source) {
    // Implementation for merging n-grams across nodes
    // This enables BitTorrent-style distributed learning
  }
}

module.exports = NgramTrainer;
