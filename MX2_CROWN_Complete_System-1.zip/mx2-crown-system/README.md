# 👑 MX2 CROWN System - Complete Implementation

## Overview

The MX2 CROWN System is a fully-featured decentralized AI ecosystem that combines:

- **Modular AI Personalities** (Crowns) - Switchable AI model configurations
- **ASX Token Economy** - Native cryptocurrency on Base Network
- **20+ AI Model Integrations** - OpenAI, Anthropic, Google, Meta, and more
- **Hybrid AI Models** - Consensus voting, cascade routing, mixture of experts
- **N-gram Training with SCX Compression** - 75% storage reduction
- **Non-Custodial Wallet** - Users control their own private keys
- **Marketplace** - Buy/sell custom AI configurations
- **Social Rewards** - Earn tokens for sharing and referrals
- **Token-Gated Features** - Premium AI models and features

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your API keys
```

### 3. Start Server

```bash
npm start
```

### 4. Access Application

```
http://localhost:3000
```

## Project Structure

```
mx2-crown-system/
├── server.js                 # Main server
├── package.json              # Dependencies
├── .env.example              # Environment template
├── README.md                 # This file
├── src/
│   ├── crowns/               # Crown configurations
│   ├── tapes/                # AI model API configs
│   │   └── all-tapes.json    # 20+ LLM integrations
│   ├── ngrams/               # N-gram training
│   │   ├── trainer.js        # Training system
│   │   └── scx-compressor.js # SCX compression
│   ├── wallet/               # Wallet system
│   ├── blockchain/           # Base network integration
│   ├── marketplace/          # Tape marketplace
│   └── routes/               # API endpoints
├── public/                   # Frontend files
└── config/                   # Configuration files
```

## API Integrations

### Supported AI Providers

- **OpenAI** - GPT-4 Turbo, GPT-3.5
- **Anthropic** - Claude Opus, Sonnet, Haiku
- **Google** - Gemini Pro, Ultra
- **Meta** - Llama 3 70B, 8B
- **Cohere** - Command, Command-Light
- **Mistral AI** - Large, Medium
- **Perplexity** - Online, Chat
- **Local Ollama** - Llama 2, Mixtral, CodeLlama

### Hybrid Models

- **Consensus Voting** - Multiple models vote on best answer
- **Best-of-N Sampling** - Generate N responses, select best
- **Cascade Routing** - Try fast model first, escalate if needed
- **Mixture of Experts** - Route to specialized model by task type
- **Parallel Execution** - Run multiple models simultaneously

## ASX Token Integration

### Contract Details

- **Address**: `0xc9c3c145fa09C2591d2492E6849B937Ea86B05Fe`
- **Network**: Base Mainnet (Chain ID: 8453)
- **Symbol**: ASX
- **Decimals**: 18

### Token Utility

- Access premium AI models
- Purchase custom tapes in marketplace
- Submit training data (RLHF)
- Unlock storage expansion
- Earn through social rewards
- Higher API rate limits

## Features

### 1. Crown System

Modular AI personalities that can be dynamically switched based on task requirements.

### 2. N-gram Training

Advanced language model training using:
- Unigrams (50,000 tokens)
- Bigrams (500,000 pairs)
- Trigrams (1,500,000 triples)
- Quadgrams (3,000,000 quads)
- Pentagrams (4,500,000 patterns)

With SCX compression reducing storage by 75%.

### 3. Marketplace

Users can create and sell custom AI configurations:
- Submit custom tapes
- Set ASX token pricing
- 70% creator revenue share
- Rating and review system

### 4. Social Rewards

Earn ASX tokens by:
- Twitter shares (+50 ASX)
- Facebook shares (+30 ASX)
- Referrals (+200 ASX per signup)
- Blog articles (+300 ASX)
- YouTube reviews (+200 ASX)

### 5. Non-Custodial Wallet

- Client-side key generation
- AES-256-GCM encryption
- MetaMask integration
- Multi-chain support
- 12-word mnemonic backup

## Security

- Private keys stored only in environment variables
- All webhooks verified via signature
- Rate limiting per user tier
- Input sanitization
- HTTPS-only connections
- JWT token expiration
- Audit logs for all transactions
- Smart contract professionally audited

## Development

### Run Tests

```bash
npm test
```

### Start Development Server

```bash
npm run dev
```

### Deploy

```bash
npm run deploy
```

## Environment Variables

See `.env.example` for complete list. Required variables:

- `STRIPE_SECRET_KEY` - For fiat payments
- `BASESCAN_API_KEY` - For blockchain queries
- `ADMIN_PRIVATE_KEY` - For token minting (secure!)
- `OPENAI_API_KEY` - For GPT models
- `ANTHROPIC_API_KEY` - For Claude models
- And more...

## Documentation

Full documentation available at:
https://docs.mx2crown.com

## Support

- Discord: https://discord.gg/mx2crown
- Email: support@mx2crown.com
- GitHub Issues: https://github.com/mx2crown/issues

## License

MIT License - See LICENSE file for details

---

**Built with ❤️ by the MX2 CROWN Team**

*Decentralized AI for Everyone* 🚀👑
