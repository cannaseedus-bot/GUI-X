#!/bin/bash

echo "🚀 MX2 CROWN System - Quick Setup"
echo "=================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed"
echo ""

# Create .env if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "✅ .env file created"
    echo "⚠️  Please edit .env and add your API keys"
else
    echo "✅ .env file already exists"
fi

echo ""

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p ASX-RAM/v1/ngrams
mkdir -p logs
mkdir -p uploads
echo "✅ Directories created"
echo ""

# Run health check
echo "🏥 Running health check..."
node -e "console.log('Node.js is working!')" && echo "✅ Health check passed" || echo "❌ Health check failed"
echo ""

echo "=================================="
echo "✨ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env and add your API keys"
echo "2. Run 'npm start' to start the server"
echo "3. Visit http://localhost:3000"
echo ""
echo "For help, visit: https://docs.mx2crown.com"
echo "=================================="
